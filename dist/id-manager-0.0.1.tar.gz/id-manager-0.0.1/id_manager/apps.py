from django.apps import AppConfig


class IdManagerConfig(AppConfig):
    name = 'id_manager'